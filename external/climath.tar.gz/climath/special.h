#ifndef SPECIAL_H_
#define SPECIAL_H_

double gammp(double a, double x);
double gammq(double a, double x);

#endif
